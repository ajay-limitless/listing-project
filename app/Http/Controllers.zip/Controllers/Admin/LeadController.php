<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Lead;
class LeadController extends Controller
{
    public function index(){
        $leads= Lead::paginate(10);

        return view('admin.leads.index', compact('leads'));
    }


    public function create(){
        return view('admin.leads.create');
    }

    public function store(Request $request){
        $request->validate([
            'title' => 'required',
            'type' => 'required',
            'address' => 'required',
            'bedrooms' => 'required',
            'bathrooms' => 'required'
        ]);

        $lead= new Lead();
        $lead->name = $request->name;
        $lead->email = $request->email;
        $lead->bedrooms = $request->bedrooms;
        $lead->bathrooms = $request->bathrooms;
        $lead->source = $request->source;
        $lead->priority = $request->priority;
        $lead->property_type = $request->property_type;
        $lead->status = $request->status;
        $lead->lead_type = $request->lead_type;
        $lead->type = $request->type;
        $lead->address = $request->address;
        $lead->notes = $request->notes;
        $lead->phone = $request->phone;
        $lead->save();

        toastr()->success('staff Created Successfully');
        return redirect()->route('admin.lead.index');
    }
}
