<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Agent;
use Illuminate\Support\Facades\Hash;

class AgentController extends Controller
{
    public function index(){
        $agents= Agent::paginate(10);

        return view('admin.agent.index', compact('agents'));
    }

    public function create(){
        return view ('admin.agent.create');
    }

    public function store(Request $request){
        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
            'address' => '',
            'phone' => 'required',
            'password' => 'required|confirmed'
        ]);

        $agent = new Agent();

        $agent->first_name = $request->name;
        $agent->last_name = $request->name;
        $agent->email = $request->email;
        $agent->address = $request->address;
        $agent->phone = $request->phone;
        $agent->avatar = "";
        $agent->password = Hash::make($request->password);

        $agent->save();
        toastr()->success('Agent Created Successfully');
        return redirect()->route('admin.agent.index');
    }

    public function delete(Request $request){
        $request->validate(['id'=>'required']);

        $agent=Agent::where('id', $request->id)->first();
        if($agent != null){
            $agent->delete();
            return response()->json([  'status'=>'true',
            'message'=>'Deleted Successfully',
        ],200);
    }
    else
    {
        return response()->json([
            'status'=>'false',
            'message'=>'Data not found',
        ],404);
    }
  }
}
